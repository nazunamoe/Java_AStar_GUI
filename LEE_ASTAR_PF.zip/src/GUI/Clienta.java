package GUI;

import java.awt.*;

import javax.swing.*;

import Astar.Main;

public class Clienta  {
	public static void main(String[] args) {	
			new Intro();
//		Main ASTAR = new Main();	
//			new GUI();
			new Intro();
	}
}
